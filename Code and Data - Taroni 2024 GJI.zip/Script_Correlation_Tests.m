% Script for the tests of correlation between magnitudes
% Taroni 2024 - GJI

% To change the catalog to be used in the computations (1985-2001 or
% 2002-2022), see lines 10 and 11, and comment (putting "%") or uncomment
% (removing "%") to select the proper catalog.

% load the catalog in ZMAP format, with 11th column containing the
% magnitude of completeness (Mc)
 Cat = importdata( 'SCSN_2002_2022_Mc35_STAI.txt' ) ;
%Cat = importdata( 'SCSN_1985_2001_Mc33_STAI.txt' ) ;

% magnitude of completeness (lower level)
Magn_Compl = min( Cat(:,11 ) ) ;

% selection of event above the completeness, without considering STAI
Cat_with_STAI = Cat( Cat(:,6) >= Magn_Compl , : ) ;

% selection of event above the completeness, removing STAI
Cat_Compl = Cat( ( Cat(:,6) >= Cat(:,11) ) & ( Cat(:,11) == Magn_Compl ) , : ) ;


%%% test on correlations %%%

% perform the runs test and show the results for the complete catalog
% (STAI not removed)
[ H_Runs_STAI , Pvalue_Runs_STAI , Stats_Runs_STAI ] = runstest( Cat_with_STAI( : , 6 ) ) ;
Pvalue_Runs_STAI

% perform the test on the correlation coefficient and show the results
% for the complete catalog (STAI not removed)
[ Rho_Corr_STAI , Pvalue_Corr_STAI ] = corr( Cat_with_STAI( 1 : end-1 , 6 ) , Cat_with_STAI( 2 : end , 6 ) ) ;
Pvalue_Corr_STAI


% perform the runs test and show the results for the complete catalog
% (STAI removed)
[ H_Runs_Compl , Pvalue_Runs_Compl , Stats_Runs_Compl ] = runstest( Cat_Compl( : , 6 ) ) ;
Pvalue_Runs_Compl


% perform the test on the correlation coefficient and show the results
% for the complete catalog (STAI removed)
[ Rho_Corr_Compl , Pvalue_Corr_Compl ] = corr( Cat_Compl( 1 : end-1 , 6  ) , Cat_Compl( 2 : end , 6 ) ) ;
Pvalue_Corr_Compl


